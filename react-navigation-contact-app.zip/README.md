# React Navigation Contact App

This is a simple multi-screen React Native app built with Expo and React Navigation for IT 320.

## Features

- Contact list screen
- Contact detail screen
- Settings screen
- Stack Navigator
- Bottom Tab Navigator
- Navigation params
- Tab bar icons
- FlatList
- StyleSheet styling

## How it works

The Contacts tab shows a list of contacts using FlatList.  
When the user taps a contact, the app uses `navigation.navigate()` to go to the detail screen.

The contact object is passed as a navigation param:

```javascript
navigation.navigate("ContactDetail", { contact: contact });
```

The detail screen reads the data using `route.params`.

## React Navigation Concepts Used

- NavigationContainer
- createStackNavigator
- createBottomTabNavigator
- navigation.navigate()
- route.params
- navigation.goBack()
- screen options
- tab bar icons

## Author

Alex
