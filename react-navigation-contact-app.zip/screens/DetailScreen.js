import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";

export default function DetailScreen({ route, navigation }) {
  // route.params receives the data passed from HomeScreen
  const { contact } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{contact.name}</Text>

      <Text style={styles.info}>Phone: {contact.phone}</Text>
      <Text style={styles.info}>Email: {contact.email}</Text>

      <Button title="Go Back" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 25,
    backgroundColor: "#ffffff",
  },

  title: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 20,
  },

  info: {
    fontSize: 18,
    marginBottom: 10,
  },
});
