import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <Text style={styles.text}>
        This is the second tab of the app. It shows how a Tab Navigator can
        separate the app into different sections.
      </Text>

      <Text style={styles.text}>
        The Contacts tab uses a Stack Navigator inside the tab to move from the
        contact list to the contact detail screen.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 25,
    backgroundColor: "#f4f4f4",
  },

  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 15,
  },

  text: {
    fontSize: 16,
    marginBottom: 12,
  },
});
