import React from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

const contacts = [
  { id: "1", name: "Alex Oliveira", phone: "555-0101", email: "alex@email.com" },
  { id: "2", name: "Maria Santos", phone: "555-0102", email: "maria@email.com" },
  { id: "3", name: "John Miller", phone: "555-0103", email: "john@email.com" },
  { id: "4", name: "Ana Costa", phone: "555-0104", email: "ana@email.com" },
  { id: "5", name: "David Lee", phone: "555-0105", email: "david@email.com" },
];

export default function HomeScreen({ navigation }) {
  // When the user taps a contact, this sends the contact data to the detail screen
  const handlePress = (contact) => {
    navigation.navigate("ContactDetail", { contact: contact });
  };

  // This function controls how each row looks in the FlatList
  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.card} onPress={() => handlePress(item)}>
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.phone}>{item.phone}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Contact List</Text>

      <FlatList
        data={contacts}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f4f4f4",
  },

  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 15,
  },

  card: {
    backgroundColor: "white",
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },

  name: {
    fontSize: 18,
    fontWeight: "bold",
  },

  phone: {
    color: "#555",
    marginTop: 4,
  },
});
