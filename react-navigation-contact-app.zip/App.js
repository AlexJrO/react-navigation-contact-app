import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";

import HomeScreen from "./screens/HomeScreen";
import DetailScreen from "./screens/DetailScreen";
import SettingsScreen from "./screens/SettingsScreen";

// Stack navigator is used for moving from the list screen to detail screen
const Stack = createStackNavigator();

// Tab navigator is used for the main bottom navigation
const Tab = createBottomTabNavigator();

function ContactsStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: "#1F4E79" },
        headerTintColor: "#fff",
      }}
    >
      <Stack.Screen
        name="Contacts"
        component={HomeScreen}
        options={{ title: "My Contacts" }}
      />

      <Stack.Screen
        name="ContactDetail"
        component={DetailScreen}
        options={{ title: "Contact Details" }}
      />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,

          // This adds icons to the tab bar
          tabBarIcon: ({ color, size }) => {
            let iconName = "home";

            if (route.name === "ContactsTab") {
              iconName = "people";
            }

            if (route.name === "Settings") {
              iconName = "settings";
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },

          tabBarActiveTintColor: "#1F4E79",
          tabBarInactiveTintColor: "gray",
        })}
      >
        <Tab.Screen
          name="ContactsTab"
          component={ContactsStack}
          options={{ title: "Contacts" }}
        />

        <Tab.Screen
          name="Settings"
          component={SettingsScreen}
          options={{ title: "Settings" }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
